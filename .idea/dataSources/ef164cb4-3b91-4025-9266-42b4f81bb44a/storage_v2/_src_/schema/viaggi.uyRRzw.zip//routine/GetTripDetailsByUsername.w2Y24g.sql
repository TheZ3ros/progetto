create
    definer = root@localhost procedure GetTripDetailsByUsername(IN username varchar(255))
BEGIN
DECLARE done INT DEFAULT FALSE;
    DECLARE city_value VARCHAR(255);
    DECLARE price_value float;
    DECLARE date_and_value DATE;
    DECLARE available_value INT;
    DECLARE image_value LONGBLOB;
    DECLARE data_rit_value DATE;
    DECLARE stato BIT;
    -- Seleziona gli attributi dalla tabella utilizzando l'id di input
        DECLARE cur CURSOR FOR
    SELECT city,price,data_and,available,image,data_rit,state
    FROM user_has_trip left join trip on tripid=trip_tripid
    WHERE UsernameUser=username;
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
     DROP TEMPORARY TABLE IF EXISTS TripUser;
    CREATE TEMPORARY TABLE TripUser (
        citta VARCHAR(255),
        prezzo FLOAT,
        data_and DATE,
        data_rit DATE,
        disp INT,
        imagine LONGBLOB,
        stato BIT
    );
    SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
    START TRANSACTION;
    OPEN cur;
    read_loop: LOOP
        FETCH cur INTO city_value,price_value,date_and_value,available_value,image_value,data_rit_value,stato;
        IF done THEN
            LEAVE read_loop;
        END IF;
                INSERT INTO TripUser VALUES (city_value,price_value,date_and_value,data_rit_value,available_value,image_value,stato);
    END LOOP;
    CLOSE cur;

    SELECT * FROM TripUser;

    COMMIT;

END;

