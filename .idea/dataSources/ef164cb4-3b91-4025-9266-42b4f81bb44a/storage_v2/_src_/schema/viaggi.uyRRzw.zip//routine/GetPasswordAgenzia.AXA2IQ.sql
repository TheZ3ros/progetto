create
    definer = root@localhost procedure GetPasswordAgenzia(IN in_username varchar(255), OUT out_password varchar(255))
BEGIN
    SELECT password
    INTO out_password
    FROM credenziali_agenzia
    WHERE nome_agenzia = in_username;
END;

