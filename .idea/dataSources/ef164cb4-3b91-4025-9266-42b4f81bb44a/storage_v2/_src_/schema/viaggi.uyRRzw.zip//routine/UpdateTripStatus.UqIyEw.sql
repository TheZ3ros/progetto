create
    definer = root@localhost procedure UpdateTripStatus(IN id int, IN username varchar(255))
BEGIN
	UPDATE user_has_trip SET state = true WHERE UsernameUser = username AND trip_tripid = id;
END;

