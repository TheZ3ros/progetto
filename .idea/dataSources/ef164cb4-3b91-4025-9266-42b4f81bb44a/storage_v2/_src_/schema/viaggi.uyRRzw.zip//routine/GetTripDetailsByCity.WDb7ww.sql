create
    definer = root@localhost procedure GetTripDetailsByCity(IN citta varchar(255))
BEGIN
DECLARE done INT DEFAULT FALSE;
    DECLARE price_value float;
    DECLARE date_and_value DATE;
    DECLARE available_value INT;
    DECLARE image_value LONGBLOB;
    DECLARE data_rit_value DATE;
    -- Seleziona gli attributi dalla tabella utilizzando l'id di input
        DECLARE cur CURSOR FOR
    SELECT `price`,`data_and`,`available`,`image`,`data_rit`
    FROM trip
    WHERE city=citta;
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
     DROP TEMPORARY TABLE IF EXISTS `Trips`;
    CREATE TEMPORARY TABLE `Trips` (
        `prezzo` FLOAT,
        `data_and` DATE,
        `data_rit`DATE,
        `disp` INT,
        `imagine` LONGBLOB
    );
    OPEN cur;
    read_loop: LOOP
        FETCH cur INTO price_value,date_and_value,available_value,image_value,data_rit_value;
        IF done THEN
            LEAVE read_loop;
        END IF;
                INSERT INTO `Trips` VALUES (price_value,date_and_value,data_rit_value,available_value,image_value);
    END LOOP;
    CLOSE cur;

    SELECT * FROM `Trips`;

    COMMIT;

END;

