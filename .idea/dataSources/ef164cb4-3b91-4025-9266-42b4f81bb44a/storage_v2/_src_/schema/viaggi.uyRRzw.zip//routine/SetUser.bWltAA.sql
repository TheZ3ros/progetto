create
    definer = root@localhost procedure SetUser(IN username varchar(45), IN in_password varchar(45),
                                               IN in_nome varchar(45), IN in_cognome varchar(45), IN email varchar(45))
BEGIN
INSERT INTO user (Username,password,nome,cognome,email)
VALUES (username, in_password,in_nome,in_cognome,email);
END;

