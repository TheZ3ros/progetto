create
    definer = root@localhost procedure CheckUserTrip(IN id int, IN username varchar(255))
BEGIN
SELECT COUNT(*) 
FROM user_has_trip 
WHERE trip_tripid = id AND UsernameUser = username;
END;

