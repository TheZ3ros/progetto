create
    definer = root@localhost procedure GetTripStatus(IN id int)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE stato BIT;
    DECLARE username VARCHAR(45);

    DECLARE cur CURSOR FOR
    SELECT state, UsernameUser
    FROM user_has_trip
    WHERE trip_tripid = id
    AND state = false;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    DROP TEMPORARY TABLE IF EXISTS userstate;
    CREATE TEMPORARY TABLE userstate (
        stato BIT,
        username VARCHAR(45)
    );

    OPEN cur;
    read_loop: LOOP
        FETCH cur INTO stato, username;
        IF done THEN
            LEAVE read_loop;
        END IF;
        INSERT INTO userstate VALUES (stato, username); 
    END LOOP;
    CLOSE cur;


    SELECT * FROM userstate;
END;

