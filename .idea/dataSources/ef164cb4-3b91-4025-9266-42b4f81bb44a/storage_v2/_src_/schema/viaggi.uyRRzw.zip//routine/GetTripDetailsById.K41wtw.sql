create
    definer = root@localhost procedure GetTripDetailsById(IN trip_value int, OUT city_value varchar(255),
                                                          OUT price_value float, OUT date_and_value date,
                                                          OUT available_value int, OUT image_value longblob,
                                                          OUT data_rit_value date)
BEGIN
    -- Seleziona gli attributi dalla tabella utilizzando l'id di input
    SELECT city, price, data_and, available, image, data_rit
    INTO  city_value, price_value, date_and_value, available_value, image_value, data_rit_value
    FROM trip
    WHERE tripid = trip_value;

END;

