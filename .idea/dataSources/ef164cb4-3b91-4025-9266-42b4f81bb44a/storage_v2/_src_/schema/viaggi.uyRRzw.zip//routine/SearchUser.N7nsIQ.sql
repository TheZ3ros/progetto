create
    definer = root@localhost procedure SearchUser(IN usern varchar(45), OUT outnome varchar(45),
                                                  OUT outcognome varchar(45), OUT outemail varchar(45))
BEGIN
SELECT nome,cognome,email
INTO outnome, outcognome, outemail
FROM user
WHERE Username=usern;
END;

