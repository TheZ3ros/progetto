create
    definer = root@localhost procedure AddTrip(IN p_città varchar(45), IN p_disponibile int, IN p_andata date,
                                               IN p_ritorno date, IN p_prezzo int, IN p_immagine longblob)
BEGIN
	INSERT INTO trip (city,available,data_and,data_rit,price,image) VALUES (p_città,p_disponibile,p_andata,p_ritorno,p_prezzo,p_immagine);
END;

