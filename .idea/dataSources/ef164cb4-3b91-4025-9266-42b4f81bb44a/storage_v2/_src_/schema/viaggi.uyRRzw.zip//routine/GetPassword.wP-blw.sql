create
    definer = root@localhost procedure GetPassword(IN in_username varchar(255), OUT out_password varchar(255))
BEGIN
    SELECT password
    INTO out_password
    FROM user
    WHERE Username = in_username;
END;

