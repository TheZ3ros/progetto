create
    definer = root@localhost procedure decrementa(IN id int)
BEGIN
UPDATE trip
SET available= available - 1
WHERE tripid=id;
END;

