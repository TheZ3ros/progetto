create
    definer = root@localhost procedure GetBuono(IN in_codice varchar(45), OUT out_valore int)
BEGIN
    SELECT valore
    INTO out_valore
    FROM buono
    WHERE codice = in_codice;
END;

