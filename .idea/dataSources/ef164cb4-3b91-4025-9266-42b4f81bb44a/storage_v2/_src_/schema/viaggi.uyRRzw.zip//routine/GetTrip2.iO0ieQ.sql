create
    definer = root@localhost procedure GetTrip2()
BEGIN
 SELECT available, price, date_and, data_rit, image, city
 FROM trip;
END;

