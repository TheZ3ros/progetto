create
    definer = root@localhost procedure SetTrip(IN id int, IN username varchar(255))
BEGIN
    INSERT INTO user_has_trip (UsernameUser, trip_tripid, state)
    VALUES (username, id, 'in_attesa');  -- o 'prenotato', 'richiesta', ecc.
END;

