create
    definer = root@localhost procedure SetTrip(IN id int, IN username varchar(255))
BEGIN
INSERT INTO user_has_trip (UsernameUser,trip_tripid)
VALUES (username, id);
END;

